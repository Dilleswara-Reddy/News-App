//
//  NewsViewModel.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import Foundation

protocol Delegate: AnyObject {
	func response(response: Articles?)
}

protocol DetailDelegate: AnyObject {
	func likesData(data: Likes?)
	func commentsData(data: Comments?)
}

enum DataModel {
	case Articles
	case Likes
	case Comments
}

class NewsViewModel{
	
	weak var delegate : Delegate?
	weak var detailDelegate: DetailDelegate?
	func loadData(urlString: String, type: DataModel) {
		guard let url = URL(string: urlString) else {
			errorSender(type: type)
			return
		}
		var request = URLRequest(url: url)
		request.httpMethod = "GET"
		let task = URLSession.shared.dataTask(with: request) {[weak self] data, response, error in
			if error == nil, let data = data {
				do {
					switch(type){
					case .Articles:
						let result = try JSONDecoder().decode(Articles.self, from: data)
						self?.delegate?.response(response: result)
					case .Likes:
						let result = try JSONDecoder().decode(Likes.self, from: data)
						self?.detailDelegate?.likesData(data: result)
					case .Comments:
						let result = try JSONDecoder().decode(Comments.self, from: data)
						self?.detailDelegate?.commentsData(data: result)
					}
					
				} catch {
					self?.errorSender(type: type)
				}
			} else {
				self?.errorSender(type: type)
			}
		}
		task.resume()
	}
	
	private func errorSender(type: DataModel){
		switch(type){
		case .Articles:
			self.delegate?.response(response: nil)
		case .Likes:
			self.detailDelegate?.likesData(data: nil)
		case .Comments:
			self.detailDelegate?.commentsData(data: nil)
		}
	}
	
}
