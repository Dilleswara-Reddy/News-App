//
//  NewsModel.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import Foundation

struct Articles: Decodable {
	let articles: [NewsModel]
}

struct NewsModel: Decodable {
	let source: Source?
	let author: String?
	let title: String?
	let description: String?
	let url: String?
	let urlToImage: String?
	let publishedAt: String?
	let content: String?
}

struct Source: Decodable {
	let id: String?
	let name: String?
}

struct Likes: Decodable {
	let likes: Int?
}

struct Comments: Decodable {
	let comments: Int?
}
