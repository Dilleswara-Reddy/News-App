//
//  DetailView.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 29/10/22.
//

import UIKit

class DetailScrollView: UIScrollView {
	let view = DetailView()
	override init(frame: CGRect) {
		super.init(frame: frame)
		view.translatesAutoresizingMaskIntoConstraints = false
		self.addSubview(view)
		setUpContraints()
	}
	
	required init?(coder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
	func setUpContraints() {
		view.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
		view.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
		view.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
		view.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
	}
	
}

class DetailView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
	let viewModel = NewsViewModel()
	var newsId: String? = ""
	var likesCount: String? {
		didSet {
			likesLabel.text = likesCount
		}
	}
	var commentsCount: String? {
		didSet{
			commentsLabel.text = commentsCount
		}
	}
	let newsImage = NewsImageView()
	let authorLabel = UILabel()
	let titleLabel = UILabel()
	let descriptionLabel = UILabel()
	let contentView = UILabel()
	let AdditionalInfoButton = UIButton()
	let publishedAtLabel = UILabel()
	let additionalInfoContainer = UIView()
	let likesLabel = UILabel()
	let commentsLabel = UILabel()
	override init(frame: CGRect) {
		super.init(frame: frame)
		viewModel.detailDelegate = self
		additionalSetupForLabels()
		addViewsToTheView()
		setupContsraints()
	}
	
	required init?(coder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
	
	func setUpData(imageUrlString: String?, title: String?, author: String?, description: String?, content: String?, publishedAt: String?, id: String?) {
		newsId = id
		if let imageURLString = imageUrlString {
			newsImage.loadImage(from: imageURLString, placeHolderImage: "NewsImage")
		}
		
		titleLabel.text = title
		if let author = author, !author.isEmpty {
			authorLabel.text = "Author: " + author
		} else {
			authorLabel.text = ""
		}
		descriptionLabel.text = description
		contentView.text = content
		if let publishedAt = publishedAt {
			var split = publishedAt.split(separator: "T")
			if split[1].contains("Z") {
				split[1].removeLast()
			}
			publishedAtLabel.text = "Published At: " + split[0] + " " + split[1]
		} else {
			publishedAtLabel.text = ""
		}
		likesLabel.text = ""
		commentsLabel.text = ""
		showAdditionalInfoContainer()
	}
	
	private func additionalSetupForLabels() {
		titleLabel.translatesAutoresizingMaskIntoConstraints = false
		titleLabel.numberOfLines = 0
		titleLabel.textAlignment = .center
		titleLabel.font = UIFont.preferredFont(forTextStyle: .title1)
		authorLabel.translatesAutoresizingMaskIntoConstraints = false
		authorLabel.numberOfLines = 0
		descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
		descriptionLabel.numberOfLines = 0
		descriptionLabel.textAlignment = .natural
		descriptionLabel.font = UIFont.preferredFont(forTextStyle: .title2)
		contentView.translatesAutoresizingMaskIntoConstraints = false
		contentView.textAlignment = .left
		contentView.numberOfLines = 0
		publishedAtLabel.translatesAutoresizingMaskIntoConstraints = false
		publishedAtLabel.textAlignment = .center
		AdditionalInfoButton.translatesAutoresizingMaskIntoConstraints = false
		AdditionalInfoButton.setTitle("Additional Info", for: .normal)
		AdditionalInfoButton.setTitleColor(.systemBlue, for: .normal)
		additionalInfoContainer.translatesAutoresizingMaskIntoConstraints = false
		likesLabel.translatesAutoresizingMaskIntoConstraints = false
		likesLabel.numberOfLines = 0
		likesLabel.textAlignment = .natural
		commentsLabel.translatesAutoresizingMaskIntoConstraints = false
		commentsLabel.numberOfLines = 0
		commentsLabel.textAlignment = .natural
		newsImage.translatesAutoresizingMaskIntoConstraints = false
	}
	
	private func addViewsToTheView() {
		self.addSubview(newsImage)
		self.addSubview(titleLabel)
		self.addSubview(authorLabel)
		self.addSubview(descriptionLabel)
		self.addSubview(contentView)
		self.addSubview(publishedAtLabel)
		self.addSubview(additionalInfoContainer)
		additionalInfoContainer.addSubview(likesLabel)
		additionalInfoContainer.addSubview(commentsLabel)
		additionalInfoContainer.addSubview(AdditionalInfoButton)
		
	}
	
	private func setupContsraints() {
		let views = ["newsImage": newsImage, "titleLabel": titleLabel, "authorLabel": authorLabel, "contentView": contentView, "publishedAtLabel": publishedAtLabel, "AdditionalInfoButton": AdditionalInfoButton, "descriptionLabel": descriptionLabel,"additionalInfoContainer": additionalInfoContainer, "likesLabel": likesLabel, "commentsLabel": commentsLabel]
		let width = UIScreen.main.bounds.width/2 - 180
		var constraints = [NSLayoutConstraint]()
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-width-[newsImage(360)]", metrics: ["width": width], views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[titleLabel]", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[descriptionLabel]", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[contentView]", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[authorLabel]", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[publishedAtLabel]", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[additionalInfoContainer]", metrics: nil, views: views))

		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "V:|-[newsImage(200)]-[titleLabel]-[descriptionLabel]-16-[contentView]-16-[authorLabel]-[publishedAtLabel]-[additionalInfoContainer]", metrics: nil, views: views))

		NSLayoutConstraint.activate(constraints)
		titleLabel.centerXAnchor.constraint(equalTo: newsImage.centerXAnchor).isActive = true
		descriptionLabel.centerXAnchor.constraint(equalTo: newsImage.centerXAnchor).isActive = true
		contentView.centerXAnchor.constraint(equalTo: newsImage.centerXAnchor).isActive = true
		
		let AdditionalViews = ["AdditionalInfoButton": AdditionalInfoButton, "likesLabel": likesLabel, "commentsLabel": commentsLabel]
		var additionalConstraints = [NSLayoutConstraint]()
		additionalConstraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|[AdditionalInfoButton]", metrics: nil, views: AdditionalViews))
		additionalConstraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|[likesLabel]", metrics: nil, views: AdditionalViews))
		additionalConstraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|[commentsLabel]", metrics: nil, views: AdditionalViews))
		additionalConstraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "V:|-[AdditionalInfoButton]-[likesLabel]-[commentsLabel]-|", metrics: nil, views: AdditionalViews))
		NSLayoutConstraint.activate(additionalConstraints)
	}
	
	func showAdditionalInfoContainer() {
		if let newsId = newsId, !newsId.isEmpty {
			let likesURL = "https://cn-news-info-api.herokuapp.com/likes/" + newsId
			viewModel.loadData(urlString: likesURL, type: .Likes)
			let commentsURL = "https://cn-news-info-api.herokuapp.com/comments/" + newsId
			viewModel.loadData(urlString: commentsURL, type: .Comments)
		} else {
			self.likesCount = "Likes: " + "NA"
			self.commentsCount = "Comments: " + "NA"
		}

	}

}
extension DetailView: DetailDelegate {
	func likesData(data: Likes?) {
		DispatchQueue.main.async {
			if let likes = data {
				self.likesCount = "Likes: " + String(likes.likes ?? 0)
			} else{
				self.likesCount = "Likes: " + "NA"
			}
		}
		
	}
	
	func commentsData(data: Comments?) {
		DispatchQueue.main.async {
			if let comments = data {
				self.commentsCount = "Comments: " + String(comments.comments ?? 0)
			} else {
				self.commentsCount = "Comments: " + "NA"
			}
		}
	}
	
}
