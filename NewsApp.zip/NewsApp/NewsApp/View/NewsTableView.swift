//
//  NewsTableView.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import Foundation
import UIKit

class NewsTableView: UITableView {
	
	override init(frame: CGRect, style: UITableView.Style) {
		super.init(frame: CGRect.zero, style: .insetGrouped)
		self.translatesAutoresizingMaskIntoConstraints = false
		self.register(NewsTableViewCell.self, forCellReuseIdentifier: "NewsCell")
		self.rowHeight = UITableView.automaticDimension
		self.cellLayoutMarginsFollowReadableWidth = true
	}
	
	required init?(coder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
}
