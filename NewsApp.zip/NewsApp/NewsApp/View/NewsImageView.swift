//
//  NewsImageView.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import Foundation
import UIKit

class NewsImageView: UIImageView {
	private let imageCache = NSCache<AnyObject, UIImage>()
	
	func loadImage(from imageURLString: String?, placeHolderImage: String) {
		
		guard let imageUrlString = imageURLString, let imageURL = URL(string: imageUrlString) else {
			self.updateDefaultImage(name: placeHolderImage)
			return
		}
		
		if let cachedImage = self.imageCache.object(forKey: imageURL as AnyObject) {
			self.image = cachedImage
			return
		}
		
		DispatchQueue.global().async {
			[weak self] in
			
			if let imageData = try? Data(contentsOf: imageURL) {
				if let image = UIImage(data: imageData) {
					DispatchQueue.main.async {
						self?.imageCache.setObject(image, forKey: imageURL as AnyObject)
						self?.image = image
					}
				} else {
					self?.updateDefaultImage(name: placeHolderImage)
				}
			} else {
				self?.updateDefaultImage(name: placeHolderImage)
			}
		}
	}
	
	func updateDefaultImage(name: String) {
		DispatchQueue.main.async {
			self.image = UIImage(named: name)
		}
	}
}
