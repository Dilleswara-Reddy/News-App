//
//  NewsTableViewCell.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import UIKit

class NewsTableViewCell: UITableViewCell {
	
	let descriptionLabel = UILabel()
	let authorLabel = UILabel()
	let container = UIView()
	let separator = UIView()
	var newsImage = NewsImageView()
	override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
		super.init(style: style, reuseIdentifier: reuseIdentifier)
		self.selectionStyle = .none
		setUpSubviews()
		setUpContraints()
	}
	
	required init?(coder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
	
	func setUpSubviews() {
		descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
		descriptionLabel.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
		descriptionLabel.numberOfLines = 0
		authorLabel.translatesAutoresizingMaskIntoConstraints  = false
		authorLabel.textAlignment = .right
		container.translatesAutoresizingMaskIntoConstraints = false
		newsImage.translatesAutoresizingMaskIntoConstraints = false
		separator.translatesAutoresizingMaskIntoConstraints = false
		separator.backgroundColor = .orange
		
		self.layer.masksToBounds = true
		self.layer.borderWidth = 0.2
		self.layer.borderColor = UIColor.gray.cgColor
		contentView.addSubview(container)
		contentView.addSubview(separator)
		contentView.addSubview(authorLabel)
		container.addSubview(newsImage)
		container.addSubview(descriptionLabel)
	}
	
	func setUpContraints() {
		let views = ["descriptionLabel": descriptionLabel, "authorLabel":authorLabel, "container": container, "newsImage": newsImage, "separator": separator]
		var constraints = [NSLayoutConstraint]()
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-6-[newsImage(100)]-6-[descriptionLabel]-|", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "V:|-[newsImage(100)]-|", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "V:|-[descriptionLabel]-|", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[container]-|", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[separator]-|", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "H:|-[authorLabel]-|", metrics: nil, views: views))
		constraints.append(contentsOf: NSLayoutConstraint.constraints(withVisualFormat: "V:|-[container]-[separator]-[authorLabel]-|", metrics: nil, views: views))
		separator.heightAnchor.constraint(equalToConstant: 1/UIScreen.main.scale).isActive = true
		NSLayoutConstraint.activate(constraints)
		
	}
	
	

}
