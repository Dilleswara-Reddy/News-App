//
//  ExtensionNewsVC+TableViewDelegate.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import Foundation
import UIKit

extension NewsViewController: UITableViewDelegate {
	func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
		return .leastNormalMagnitude
	}
	func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
		return UIView()
	}
	
	func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
		detailVC.section = indexPath.section
		self.navigationController?.pushViewController(detailVC, animated: true)
	}
}
