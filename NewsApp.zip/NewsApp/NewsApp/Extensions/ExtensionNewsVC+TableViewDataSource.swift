//
//  ExtensionNewsVC+TableViewDataSource.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import Foundation
import UIKit

extension NewsViewController: UITableViewDataSource {
	func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return 1
	}
	
	func numberOfSections(in tableView: UITableView) -> Int {
		return data.count
	}
	
	func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		var cell = tableView.dequeueReusableCell(withIdentifier: "NewsCell") as! NewsTableViewCell
		let news = data[indexPath.section]
		cell.descriptionLabel.text = news.description
		cell.newsImage.loadImage(from: news.urlToImage, placeHolderImage: "NewsImage")
		cell.authorLabel.text = news.author
		return cell
	}
	
	
}
