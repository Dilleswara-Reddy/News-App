//
//  ViewController.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 28/10/22.
//

import UIKit

fileprivate(set) var data = [NewsModel]()
class NewsViewController: UIViewController {
	lazy var detailVC = DetailViewController()
	let tableView = NewsTableView()
	var viewModel = NewsViewModel()
	let urlString = "https://newsapi.org/v2/top-headlines?country=us&apiKey=919b2af02ceb4a9387149816b8c185e0"
	override func viewDidLoad() {
		super.viewDidLoad()
		tableView.delegate = self
		tableView.dataSource = self
		viewModel.delegate = self
		self.navigationItem.title = "US top headlines news"
		viewModel.loadData(urlString: urlString, type: .Articles)
		view.addSubview(tableView)
		setUpConstraints()
		// Do any additional setup after loading the view.
	}
	fileprivate func reloadTableView() {
		DispatchQueue.main.async {
			self.tableView.reloadData()
		}
	}
	
	func setUpConstraints() {
		tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
		tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
		tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true
		tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
	}
}

extension NewsViewController: Delegate {
	func response(response: Articles?) {
		if let articles = response {
			data = articles.articles
			reloadTableView()
		} else {
			let alert = UIAlertController(title: "Sorry", message: "Some error occured. Please try again", preferredStyle: .alert)
			let okButton = UIAlertAction(title: "Cancel", style: .cancel)
			let tryAgainButton = UIAlertAction(title: "Try Again", style: .default){ _ in
				self.viewModel.loadData(urlString: self.urlString, type: .Articles)
			}
			alert.addAction(okButton)
			alert.addAction(tryAgainButton)
			DispatchQueue.main.async {
				self.present(alert, animated: true)
			}
		}
	}

}

