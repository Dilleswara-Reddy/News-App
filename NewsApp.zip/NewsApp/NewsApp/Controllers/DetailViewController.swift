//
//  DetailViewController.swift
//  NewsApp
//
//  Created by Dayyala Dilleswara Reddy on 29/10/22.
//

import UIKit

class DetailViewController: UIViewController {

	var section : Int?
	let detailView = DetailScrollView()
	override func viewDidLoad() {
		super.viewDidLoad()
		view.backgroundColor = .systemBackground
		view.addSubview(detailView)
		
		// Do any additional setup after loading the view.
	}
	override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)
		setUpConstraints()
		updateView()
	}
	
	override func viewDidAppear(_ animated: Bool) {
		detailView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height + 100)
	}
	
	private func setUpConstraints() {
		detailView.translatesAutoresizingMaskIntoConstraints = false
		detailView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
		detailView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
		detailView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
		detailView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
	}
	
	private func updateView() {
		guard let section = section else {
			return
		}
		let news = data[section]
		self.navigationItem.title = news.source?.name
		detailView.view.setUpData(imageUrlString: news.urlToImage, title: news.title, author: news.author, description: news.description, content: news.content, publishedAt: news.publishedAt, id: news.source?.id)
	}


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
